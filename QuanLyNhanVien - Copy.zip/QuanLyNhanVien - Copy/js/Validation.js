function Validation() {
    // Phương thức kiểm tra dữ liệu
    // Kiểm tra rỗng
    this.kiemTraRong = function (inputVal, message, spanID) {
        //  Nếu giá trị bị rỗng
        if (inputVal == "") {
            // == so sánh giá trị
            // === so sánh giá trị và kiểu dữ liệu
            // Dữ liệu sai
            document.getElementById(spanID).innerHTML = message;
            document.getElementById(spanID).style.display = "block";
            return false;
        }

        // Dữ liệu đúng (hợp lệ)
        document.getElementById(spanID).innerHTML = "";
        document.getElementById(spanID).style.display = "none";
        return true;
    }
    // Kiểm tra mã trùng
    this.kiemTraTrung = function (inputVal, message, spanID, mangNV) {
        // some trả kết quả boolean 
        var isExist = mangNV.some(function (item, index) {
            // Tìm thấy mã bị trùng trong mảng nhân viên thì trả kết quả là true
            return item.maNV == inputVal;
        });
        console.log(isExist);

        // Có mã trùng
        if (isExist) {
            // Dữ liệu sai
            document.getElementById(spanID).innerHTML = message;
            document.getElementById(spanID).style.display = "block";
            return false;
        }
        // Dữ liệu đúng (hợp lệ)
        document.getElementById(spanID).innerHTML = "";
        document.getElementById(spanID).style.display = "none";
        return true;
    }
    // Kiểm tra tên
    this.kiemTraTen = function (inputVal, message, spanID) {
        // C1: Dùng đối tượng có sẵn (RegExp) của javascript
        var pattern = new RegExp("^[a-zA-Z_ÀÁÂÃÈÉÊẾÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶ"
            + "ẸẺẼỀỀỂưăạảấầẩẫậắằẳẵặẹẻẽềềểếỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợ"
            + "ụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ\\s]+$");
        // Kiểm tra tên hợp lệ
        if (pattern.test(inputVal)) {
            // Dữ liệu đúng (hợp lệ)
            document.getElementById(spanID).innerHTML = "";
            document.getElementById(spanID).style.display = "none";
            return true;



        }
        // Dữ liệu sai
        document.getElementById(spanID).innerHTML = message;
        document.getElementById(spanID).style.display = "block";
        return false;
    }

    // Kiểm tra email
    this.kiemTraEmail = function (inputVal, message, spanID) {
        // C2: Dùng chuỗi RegExp
        var emailPatt = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (inputVal.match(emailPatt)) {
            // Dữ liệu đúng (hợp lệ)
            document.getElementById(spanID).innerHTML = "";
            document.getElementById(spanID).style.display = "none";
            return true;
        }
        // Dữ liệu sai
        document.getElementById(spanID).innerHTML = message;
        document.getElementById(spanID).style.display = "block";
        return false;
    }

    // Kiểm tra độ dài password
    this.kiemTraDoDai = function (inputVal, message, spanID, min, max) {
        // Nếu độ dài: min<=password<=max
        if (inputVal.length >= min && inputVal.length <= max) {

            // Dữ liệu đúng (hợp lệ)
            document.getElementById(spanID).innerHTML = "";
            document.getElementById(spanID).style.display = "none";
            return true;
        }
        // Dữ liệu sai
        document.getElementById(spanID).innerHTML = message;
        document.getElementById(spanID).style.display = "block";
        return false;

    }
    // Kiểm tra chức vụ
    this.kiemTraChucVu = function (selectID, message, spanID) {
        var index = document.getElementById(selectID).selectedIndex;
        // Nếu hợp lệ (không chọn lựa chọn đầu tiên)
        if (index != 0) {


            // Dữ liệu đúng (hợp lệ)
            document.getElementById(spanID).innerHTML = "";
            document.getElementById(spanID).style.display = "none";
            return true;
        }
        // Dữ liệu sai
        document.getElementById(spanID).innerHTML = message;
        document.getElementById(spanID).style.display = "block";
        return false;
    }


}