function NhanVien(MaNhanVien, TenNhanVien, LuongCB, ChucVu, GioLamTrongThang) {
   //thuộc tính

   this.MaNhanVien = MaNhanVien;
   this.TenNhanVien = TenNhanVien;
   this.LuongCB = LuongCB;
   this.ChucVu = ChucVu;
   this.GioLamTrongThang = GioLamTrongThang;

}