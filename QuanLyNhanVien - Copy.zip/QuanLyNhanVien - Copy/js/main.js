/**
 * 1. Thêm Nhân Viên
 * 2. Hiển thị danh sách nhân viên lên table
 * 3. Xóa Nhân Viên
 * 4. Cập nhật thông tin Nhân Viên
 * 5. Validation thông tin nhân viên
 * 6. Tìm kiếm nhân viên theo tên
 */
/**
 * B1: Khai báo lớp đối tượng NhanVien, DanhSachNhanVien
 * B2: Lấy thông tin từ form (khi nhấn button)
 * B3: Thêm nhan vien mới vào mảng nhân vien
 * B4: Hiển thị danh sach nhan viên lên table
 * 
 */

// var dsnv = new DanhSachNhanVien();
var validation = new Validation();

//hàm rút gọn cú pháp getElementbyID
function getELE(id) {
    return document.getElementById(id);
}

/**
//Xử lý form cho chức năng thêm NV
getELE("btnThem").addEventListener("click", function () {
    //hiện button thêm người dùng
    getELE("btnThemNV").style.display = "block";
    //ẩn button cập nhật
    getELE("btnCapNhat").style.display = "none";
    getELE("msnv").removeAttribute("disabled");

    // C1: gán lại giá trị cho input
    // getELE("msnv").value = "";

    //C2: dùng reset()
    document.getElementById("formNV").reset();
});

getELE("btnThemNV").addEventListener("click", function () {
    layThongTin()
});
*/
 
//Hàm lấy thông tin từ form
function layThongTin() {
    var maNV = getELE("msnv").value;
    var tenNV = getELE("name").value;
    var email = getELE("email").value;
    var password = getELE("password").value;
    var ngayLam = getELE("datepicker").value;
    var chucVu = getELE("chucvu").value;

    // console.log(maNV, tenNV, email, password, ngayLam, chucVu);

    var isValid = true;
    //Kiểm tra mã nhân viên(không để trống, không bị trùng)
    //& cộng theo bit
    // isValid = isValid(giá trị cũ) & validation (giá trị mới)
    // isValid (true=1) = true(1)&& true(1)
    isValid &= validation.kiemTraRong(maNV, "Mã nhân viên không được để trống!", "tbMaNV") && validation.kiemTraTrung(maNV, "Mã NV không được trùng!", "tbMaNV", dsnv.mangNV);
    //Kiểm tra họ tên (không để trống, họ tên không chứa số)
    isValid &= validation.kiemTraRong(tenNV, "Tên nhân viên không được để trống!", "tbTen") && validation.kiemTraTen(tenNV, "Tên nhân viên không hợp lệ!", "tbTen");
    //kiểm tra Email
    isValid &= validation.kiemTraRong(email, "Email nhân viên không được để trống!", "tbEmail") && validation.kiemTraEmail(email, "Email nhân viên không hợp lệ!", "tbEmail");
    //Kiểm tra Password
    isValid &= validation.kiemTraRong(password, "Password nhân viên không được để trống!", "tbMatKhau") && validation.kiemTraRong(password, "Password nhân viên không hợp lệ!", "tbMatKhau", 6, 8);
    //Kiểm tra Ngày làm
    isValid &= validation.kiemTraRong(ngayLam, "Ngày làm nhân viên không được để trống!", "tbNgay");
    //Kiểm tra chức vụ
    isValid &= validation.kiemTraChucVu("chucvu", "Chức vụ nhân viên không hợp lệ!", "tbChucVu");



    console.log(isValid);
    //isValid == true
    //Dữ liệu đúng
    if (isValid) {
        var nv = new NhanVien(maNV, tenNV, email, password, ngayLam, chucVu);
        // console.log(nv);    
        dsnv.themNhanVien(nv);
        console.log(dsnv.mangNV);
        //gọi hàm
        hienThi(dsnv.mangNV);
        //gọi hàm 
        setLocalStorage();
    }

}

/**
//lưu mảng NV vào localStorage của browser
function setLocalStorage() {
    //localStorage chỉ cho phép lưu kiểu Json 
    //để chuyển từ kiểu mảng sang json dùng JSON.stringify    
    localStorage.setItem("DSNV", JSON.stringify(dsnv.mangNV));
}
//Trang web load sẽ chạy hàm getLocalStorage
getLocalStorage();
function getLocalStorage() {
    //lấy DSNV từ localStorage
    //Do kiểu dữ liệu là JSON nên cần chuyển về kiểu mảng
    //kiểm tra có localStorage
    if (localStorage.getItem("DSNV") != null) {
        //nếu có localStorage thì lấy local lên và hiển thị
        dsnv.mangNV = JSON.parse(localStorage.getItem("DSNV"));
        hienThi(dsnv.mangNV);
    }
}


//Khai báo
function hienThi(mangNV) {
    var tbody = getELE("tableDanhSach");
    var content = "";
    mangNV.map(function (item, index) {
        //item: 1 phần tử của mảng (1 nv trong mảng)
        //index: vị trí của phần tử trong mảng
        //template string
        //content = content (nội dung cũ) + `nội dung mới`
        content += `
            <tr>
                <td>${item.maNV}</td>
                <td>${item.tenNV}</td>
                <td>${item.email}</td>
                <td>${item.ngayLam}</td>
                <td>${item.chucVu}</td>
                <td>
                    <button class="btn btn-danger" onclick="xoaNhanVien(${item.maNV})">Xóa</button>
                    <button class="btn btn-success" onclick="hienThiNhanVien(${item.maNV})" data-toggle="modal"
                    data-target="#myModal">Cập Nhật</button>
                </td>
            </tr>
        `;
    });
    tbody.innerHTML = content;
}

function xoaNhanVien(ma) {
    dsnv.xoaNV(ma);
    hienThi(dsnv.mangNV);
}

//Hiển thị thông tin nv lên form
//xử lý form của chức năng cập nhật
function hienThiNhanVien(ma) {
    //ẩn button thêm người dùng
    getELE("btnThemNV").style.display = "none";
    //hiện button cập nhật
    getELE("btnCapNhat").style.display = "block";
    //Thêm thuộc disabled cho msnv để người dùng không chỉnh sửa được
    getELE("msnv").setAttribute("disabled", true);


    var viTri = dsnv.timViTri(ma);
    getELE("msnv").value = dsnv.mangNV[viTri].maNV;
    getELE("name").value = dsnv.mangNV[viTri].tenNV;
    getELE("email").value = dsnv.mangNV[viTri].email;
    getELE("password").value = dsnv.mangNV[viTri].password;
    getELE("datepicker").value = dsnv.mangNV[viTri].ngayLam;
    getELE("chucvu").value = dsnv.mangNV[viTri].chucVu;

    getELE("btnCapNhat").setAttribute("data-manv", dsnv.mangNV[viTri].maNV);
}

function capNhat(event) {
    console.log(event);
    var ma = event.target.getAttribute("data-manv");
    console.log(ma);

    //lấy lại thông tin từ form
    var maNV = getELE("msnv").value;
    var tenNV = getELE("name").value;
    var email = getELE("email").value;
    var password = getELE("password").value;
    var ngayLam = getELE("datepicker").value;
    var chucVu = getELE("chucvu").value;
    var nv = new NhanVien(maNV, tenNV, email, password, ngayLam, chucVu);
    dsnv.capNhatNV(ma, nv);
    hienThi(dsnv.mangNV);
}

// Cách 1: Tìm kiếm sau khi click button
// getELE("btnTimNV").addEventListener("click", function () {
//     var tenTK = getELE("searchName").value.trim();
//     var mangKQ = dsnv.timKiemNV(tenTK);
//     console.log(mangKQ);
//     if(mangKQ.length > 0){
//         // Nếu tìm thấy
//         hienThi(mangKQ);
//     }
// });

// Cách 2: Tìm kiếm khi người dùng gõ trên ô input
// Keyup hoặc keydown: Khi người dùng gõ chữ lên ô input
getELE("searchName").addEventListener("keyup", function () {
    var tenTK = getELE("searchName").value.trim();
    var mangKQ = dsnv.timKiemNV(tenTK);
    console.log(mangKQ);
    if (mangKQ.length > 0) {
        // Nếu tìm thấy
        hienThi(mangKQ);
    }
});
*/
